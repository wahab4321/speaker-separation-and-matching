from pydub import AudioSegmnt
file_path = 'input\V4.mp4'
sound = AudioSegment.from_file(file_path)
sound.export("input1/sound.wav", format="wav")