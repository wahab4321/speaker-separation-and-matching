# flask render_template example
 
from flask import Flask, render_template, request, redirect, url_for
import os
from os.path import join, dirname, realpath
 
# WSGI Application
# Provide template folder name
# The default folder name should be "templates" else need to mention custom folder name
app = Flask(__name__, template_folder='templateFiles', static_folder='staticFiles')
 
# enable debugging mode
app.config["DEBUG"] = True

# Upload folder
UPLOAD_FOLDER = 'input'
app.config['UPLOAD_FOLDER'] =  UPLOAD_FOLDER


# Root URL
@app.route('/')
def index():
     # Set The upload HTML template '\templates\index.html'
    return render_template('index.html')
@app.route('/third', methods=["GET"])
def third():
     # Set The upload HTML template '\templates\index.html'
    return render_template('third.html')


# Get the uploaded files
@app.route("/upload", methods=['GET','POST'])
def uploadFiles():
     
      # get the uploaded file
      uploaded_file = request.files['file']
      print(uploaded_file)
      if uploaded_file.filename != '':
           file_path = os.path.join(app.config['UPLOAD_FOLDER'], uploaded_file.filename)
           uploaded_file.save(file_path)
           import re
           file1 = open(file_path, 'r')
           text = ""
           all_speakers = []
           for each in file1.readlines():
               text = text + each
               y = re.search(r'<NA> <NA>(.*?)<NA> <NA>', each).group(1)
               all_speakers.append(y)
           unique_speakers = list(set(all_speakers))
           unique_speakers1 = len(unique_speakers)
           valu = unique_speakers1

      return render_template('third.html', valu=valu)
     




if (__name__ == "__main__"):
     app.run(port = 5000)